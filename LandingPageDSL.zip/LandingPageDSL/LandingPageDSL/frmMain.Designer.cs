﻿namespace LandingPageDSL
{
    partial class LandingPageExpress
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFilePath = new System.Windows.Forms.Label();
            this.txtFilePath = new System.Windows.Forms.TextBox();
            this.btnPath = new System.Windows.Forms.Button();
            this.FolderDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.txtPageName = new System.Windows.Forms.TextBox();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.lalPageName = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblElementType = new System.Windows.Forms.Label();
            this.cboxElementType = new System.Windows.Forms.ComboBox();
            this.txtContent = new System.Windows.Forms.TextBox();
            this.lvElementsToAdd = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lblContent = new System.Windows.Forms.Label();
            this.lblElementsAdded = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnPreview = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnGeneratePage = new System.Windows.Forms.Button();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.checkBoxOptionCSS = new System.Windows.Forms.CheckBox();
            this.lblListType = new System.Windows.Forms.Label();
            this.cbListType = new System.Windows.Forms.ComboBox();
            this.lblListInstruction = new System.Windows.Forms.Label();
            this.lblDefinitionTitle = new System.Windows.Forms.Label();
            this.lblDefinition = new System.Windows.Forms.Label();
            this.txtDefinition = new System.Windows.Forms.TextBox();
            this.txtDefinitionTitle = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblFilePath
            // 
            this.lblFilePath.AutoSize = true;
            this.lblFilePath.Location = new System.Drawing.Point(12, 9);
            this.lblFilePath.Name = "lblFilePath";
            this.lblFilePath.Size = new System.Drawing.Size(54, 13);
            this.lblFilePath.TabIndex = 15;
            this.lblFilePath.Text = "File Path :";
            // 
            // txtFilePath
            // 
            this.txtFilePath.Location = new System.Drawing.Point(90, 6);
            this.txtFilePath.Name = "txtFilePath";
            this.txtFilePath.Size = new System.Drawing.Size(441, 20);
            this.txtFilePath.TabIndex = 1;
            this.txtFilePath.Click += new System.EventHandler(this.txtFilePath_Click);
            // 
            // btnPath
            // 
            this.btnPath.Location = new System.Drawing.Point(547, 4);
            this.btnPath.Name = "btnPath";
            this.btnPath.Size = new System.Drawing.Size(75, 23);
            this.btnPath.TabIndex = 0;
            this.btnPath.Text = " ...";
            this.btnPath.UseVisualStyleBackColor = true;
            this.btnPath.Click += new System.EventHandler(this.btnPath_Click);
            // 
            // txtPageName
            // 
            this.txtPageName.Location = new System.Drawing.Point(90, 32);
            this.txtPageName.Name = "txtPageName";
            this.txtPageName.Size = new System.Drawing.Size(100, 20);
            this.txtPageName.TabIndex = 2;
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(90, 58);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(100, 20);
            this.txtTitle.TabIndex = 3;
            // 
            // lalPageName
            // 
            this.lalPageName.AutoSize = true;
            this.lalPageName.Location = new System.Drawing.Point(12, 35);
            this.lalPageName.Name = "lalPageName";
            this.lalPageName.Size = new System.Drawing.Size(69, 13);
            this.lalPageName.TabIndex = 16;
            this.lalPageName.Text = "Page Name :";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(12, 61);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(33, 13);
            this.lblTitle.TabIndex = 17;
            this.lblTitle.Text = "Title :";
            // 
            // lblElementType
            // 
            this.lblElementType.AutoSize = true;
            this.lblElementType.Location = new System.Drawing.Point(12, 87);
            this.lblElementType.Name = "lblElementType";
            this.lblElementType.Size = new System.Drawing.Size(78, 13);
            this.lblElementType.TabIndex = 18;
            this.lblElementType.Text = "Element Type :";
            // 
            // cboxElementType
            // 
            this.cboxElementType.FormattingEnabled = true;
            this.cboxElementType.Items.AddRange(new object[] {
            "Heading1",
            "Heading2",
            "Heading3",
            "Paragraph",
            "Image",
            "List"});
            this.cboxElementType.Location = new System.Drawing.Point(90, 84);
            this.cboxElementType.Name = "cboxElementType";
            this.cboxElementType.Size = new System.Drawing.Size(100, 21);
            this.cboxElementType.TabIndex = 4;
            this.cboxElementType.SelectedIndexChanged += new System.EventHandler(this.cboxElementType_SelectedIndexChanged);
            // 
            // txtContent
            // 
            this.txtContent.Location = new System.Drawing.Point(12, 163);
            this.txtContent.Multiline = true;
            this.txtContent.Name = "txtContent";
            this.txtContent.Size = new System.Drawing.Size(289, 167);
            this.txtContent.TabIndex = 20;
            // 
            // lvElementsToAdd
            // 
            this.lvElementsToAdd.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lvElementsToAdd.Location = new System.Drawing.Point(328, 84);
            this.lvElementsToAdd.Name = "lvElementsToAdd";
            this.lvElementsToAdd.Size = new System.Drawing.Size(293, 246);
            this.lvElementsToAdd.TabIndex = 10;
            this.lvElementsToAdd.UseCompatibleStateImageBehavior = false;
            this.lvElementsToAdd.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Element Type";
            this.columnHeader1.Width = 90;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Content";
            this.columnHeader2.Width = 151;
            // 
            // lblContent
            // 
            this.lblContent.AutoSize = true;
            this.lblContent.Location = new System.Drawing.Point(12, 147);
            this.lblContent.Name = "lblContent";
            this.lblContent.Size = new System.Drawing.Size(50, 13);
            this.lblContent.TabIndex = 19;
            this.lblContent.Text = "Content :";
            // 
            // lblElementsAdded
            // 
            this.lblElementsAdded.AutoSize = true;
            this.lblElementsAdded.Location = new System.Drawing.Point(325, 68);
            this.lblElementsAdded.Name = "lblElementsAdded";
            this.lblElementsAdded.Size = new System.Drawing.Size(90, 13);
            this.lblElementsAdded.TabIndex = 26;
            this.lblElementsAdded.Text = "Elements Added :";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(226, 336);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 9;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(329, 336);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(75, 23);
            this.btnRemove.TabIndex = 11;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnPreview
            // 
            this.btnPreview.Location = new System.Drawing.Point(438, 363);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(75, 23);
            this.btnPreview.TabIndex = 12;
            this.btnPreview.Text = "Preview";
            this.btnPreview.UseVisualStyleBackColor = true;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Maroon;
            this.btnExit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnExit.Location = new System.Drawing.Point(12, 392);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(289, 30);
            this.btnExit.TabIndex = 21;
            this.btnExit.Text = "EXIT";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnGeneratePage
            // 
            this.btnGeneratePage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnGeneratePage.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnGeneratePage.Location = new System.Drawing.Point(329, 392);
            this.btnGeneratePage.Name = "btnGeneratePage";
            this.btnGeneratePage.Size = new System.Drawing.Size(293, 30);
            this.btnGeneratePage.TabIndex = 14;
            this.btnGeneratePage.Text = "GENERATE PAGE";
            this.btnGeneratePage.UseVisualStyleBackColor = false;
            this.btnGeneratePage.Click += new System.EventHandler(this.btnGeneratePage_Click);
            // 
            // btnClearAll
            // 
            this.btnClearAll.Location = new System.Drawing.Point(547, 336);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(75, 23);
            this.btnClearAll.TabIndex = 13;
            this.btnClearAll.Text = "Clear All";
            this.btnClearAll.UseVisualStyleBackColor = true;
            this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
            // 
            // checkBoxOptionCSS
            // 
            this.checkBoxOptionCSS.AutoSize = true;
            this.checkBoxOptionCSS.Location = new System.Drawing.Point(12, 342);
            this.checkBoxOptionCSS.Name = "checkBoxOptionCSS";
            this.checkBoxOptionCSS.Size = new System.Drawing.Size(81, 17);
            this.checkBoxOptionCSS.TabIndex = 8;
            this.checkBoxOptionCSS.Text = "Create CSS";
            this.checkBoxOptionCSS.UseVisualStyleBackColor = true;
            // 
            // lblListType
            // 
            this.lblListType.AutoSize = true;
            this.lblListType.Location = new System.Drawing.Point(223, 68);
            this.lblListType.Name = "lblListType";
            this.lblListType.Size = new System.Drawing.Size(56, 13);
            this.lblListType.TabIndex = 25;
            this.lblListType.Text = "List Type :";
            this.lblListType.Visible = false;
            // 
            // cbListType
            // 
            this.cbListType.FormattingEnabled = true;
            this.cbListType.Items.AddRange(new object[] {
            "Menu Bar",
            "Ordered List",
            "Unordered List",
            "Definition List"});
            this.cbListType.Location = new System.Drawing.Point(201, 84);
            this.cbListType.Name = "cbListType";
            this.cbListType.Size = new System.Drawing.Size(100, 21);
            this.cbListType.TabIndex = 5;
            this.cbListType.Visible = false;
            this.cbListType.SelectedIndexChanged += new System.EventHandler(this.cbListType_SelectedIndexChanged);
            // 
            // lblListInstruction
            // 
            this.lblListInstruction.AutoSize = true;
            this.lblListInstruction.Location = new System.Drawing.Point(139, 147);
            this.lblListInstruction.Name = "lblListInstruction";
            this.lblListInstruction.Size = new System.Drawing.Size(140, 13);
            this.lblListInstruction.TabIndex = 22;
            this.lblListInstruction.Text = "Press Enter After Each Item!";
            this.lblListInstruction.Visible = false;
            // 
            // lblDefinitionTitle
            // 
            this.lblDefinitionTitle.AutoSize = true;
            this.lblDefinitionTitle.Location = new System.Drawing.Point(44, 108);
            this.lblDefinitionTitle.Name = "lblDefinitionTitle";
            this.lblDefinitionTitle.Size = new System.Drawing.Size(37, 13);
            this.lblDefinitionTitle.TabIndex = 23;
            this.lblDefinitionTitle.Text = "TITLE";
            this.lblDefinitionTitle.Visible = false;
            // 
            // lblDefinition
            // 
            this.lblDefinition.AutoSize = true;
            this.lblDefinition.Location = new System.Drawing.Point(176, 108);
            this.lblDefinition.Name = "lblDefinition";
            this.lblDefinition.Size = new System.Drawing.Size(68, 13);
            this.lblDefinition.TabIndex = 24;
            this.lblDefinition.Text = "DEFINITION";
            this.lblDefinition.Visible = false;
            // 
            // txtDefinition
            // 
            this.txtDefinition.Enabled = false;
            this.txtDefinition.Location = new System.Drawing.Point(121, 124);
            this.txtDefinition.Name = "txtDefinition";
            this.txtDefinition.Size = new System.Drawing.Size(180, 20);
            this.txtDefinition.TabIndex = 7;
            this.txtDefinition.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDefinition_EnterKey_Pressed);
            // 
            // txtDefinitionTitle
            // 
            this.txtDefinitionTitle.Enabled = false;
            this.txtDefinitionTitle.Location = new System.Drawing.Point(15, 124);
            this.txtDefinitionTitle.Name = "txtDefinitionTitle";
            this.txtDefinitionTitle.Size = new System.Drawing.Size(100, 20);
            this.txtDefinitionTitle.TabIndex = 6;
            // 
            // LandingPageExpress
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(636, 434);
            this.Controls.Add(this.txtDefinitionTitle);
            this.Controls.Add(this.txtDefinition);
            this.Controls.Add(this.lblDefinition);
            this.Controls.Add(this.lblDefinitionTitle);
            this.Controls.Add(this.lblListInstruction);
            this.Controls.Add(this.cbListType);
            this.Controls.Add(this.lblListType);
            this.Controls.Add(this.checkBoxOptionCSS);
            this.Controls.Add(this.btnClearAll);
            this.Controls.Add(this.btnGeneratePage);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnPreview);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lblElementsAdded);
            this.Controls.Add(this.lblContent);
            this.Controls.Add(this.lvElementsToAdd);
            this.Controls.Add(this.txtContent);
            this.Controls.Add(this.cboxElementType);
            this.Controls.Add(this.lblElementType);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lalPageName);
            this.Controls.Add(this.txtTitle);
            this.Controls.Add(this.txtPageName);
            this.Controls.Add(this.btnPath);
            this.Controls.Add(this.txtFilePath);
            this.Controls.Add(this.lblFilePath);
            this.Name = "LandingPageExpress";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFilePath;
        private System.Windows.Forms.TextBox txtFilePath;
        private System.Windows.Forms.Button btnPath;
        private System.Windows.Forms.FolderBrowserDialog FolderDialog;
        private System.Windows.Forms.TextBox txtPageName;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.Label lalPageName;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblElementType;
        private System.Windows.Forms.ComboBox cboxElementType;
        private System.Windows.Forms.TextBox txtContent;
        private System.Windows.Forms.ListView lvElementsToAdd;
        private System.Windows.Forms.Label lblContent;
        private System.Windows.Forms.Label lblElementsAdded;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnPreview;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnGeneratePage;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.CheckBox checkBoxOptionCSS;
        private System.Windows.Forms.Label lblListType;
        private System.Windows.Forms.ComboBox cbListType;
        private System.Windows.Forms.Label lblListInstruction;
        private System.Windows.Forms.Label lblDefinitionTitle;
        private System.Windows.Forms.Label lblDefinition;
        private System.Windows.Forms.TextBox txtDefinition;
        private System.Windows.Forms.TextBox txtDefinitionTitle;
    }
}

