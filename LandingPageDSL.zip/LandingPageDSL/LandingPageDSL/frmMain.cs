﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;

namespace LandingPageDSL
{
    public partial class LandingPageExpress : Form
    {
        private string HTML;
        private List<String> Def_Title = new List<String>();
        private List<String> Definitions = new List<String>();

        public LandingPageExpress()
        {
            InitializeComponent();
        }
        //Open folder dialog for file creation path
        private void btnPath_Click(object sender, EventArgs e)
        {
            FolderDialog.ShowDialog();
            txtFilePath.Text = FolderDialog.SelectedPath;
        }
        //Remove first selected item in the list view
        private void btnRemove_Click(object sender, EventArgs e)
        {
            try
            {
                lvElementsToAdd.SelectedItems[0].Remove();
            }
            catch
            {
                MessageBox.Show("Removal Error!, Please check if an item is selected!");
            }
        }
        //Clears listview items and GUI fields
        private void btnClearAll_Click(object sender, EventArgs e)
        {
            lvElementsToAdd.Items.Clear();
            clear_fields();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if(cboxElementType.Text == "" || txtContent.Text == "")
            {
                MessageBox.Show("Please enter information before proceeding");
            }

            //Add elements to the list
            if (cboxElementType.Text == "List")
            {
                ListViewItem litem = new ListViewItem(cbListType.Text);
                litem.SubItems.Add(txtContent.Text);

                lvElementsToAdd.Items.Add(litem);
                clear_fields();
            }
            else
            {
                ListViewItem litem = new ListViewItem(cboxElementType.Text);
                litem.SubItems.Add(txtContent.Text);

                lvElementsToAdd.Items.Add(litem);
                clear_fields();
            }
        }
        /// <summary>
        /// Clears GUI Fields
        /// </summary>
        private void clear_fields()
        {
            txtContent.Text = "";
            cboxElementType.Text = "";
            cbListType.Text = "";
            lblListInstruction.Visible = false;
            txtDefinitionTitle.Enabled = false;
            txtDefinition.Enabled = false;
            lblListType.Visible = false;
            cbListType.Visible = false;  
        }

        private string create_list(ListViewItem item)
        {
            StringReader input = new StringReader(item.SubItems[1].Text);
            StringBuilder list = new StringBuilder();
            string link_address = @"""#""";
            string temp;
            if (item.SubItems[0].Text == "Menu Bar")
            {
                temp = @"""menu""";
                list.Append("<ul id=" + temp + ">" + Environment.NewLine);
                while(input.Peek() != -1)
                {
                    string listItem = input.ReadLine();
                    list.Append("\t<li><a href =" + link_address + ">" + listItem + "</a></li>" + Environment.NewLine);
                }
                list.Append("</ul>" + Environment.NewLine);
            }
            else if (item.SubItems[0].Text == "Ordered List")
            {
                list.Append("<ol>" + Environment.NewLine);
                while (input.Peek() != -1)
                {
                    string listItem = input.ReadLine();
                    list.Append("\t<li>" + listItem + "</li>" + Environment.NewLine);
                }
                list.Append("</ol>" + Environment.NewLine);
            }
            else if (item.SubItems[0].Text == "Unordered List")
            {
                list.Append("<ul>" + Environment.NewLine);
                while (input.Peek() != -1)
                {
                    string listItem = input.ReadLine();
                    list.Append("\t<li>" + listItem + "</li>" + Environment.NewLine);
                }
                list.Append("</ul>" + Environment.NewLine);
            }
            else if (item.SubItems[0].Text == "Definition List")
            {
                if (Def_Title.Count > 0 || Definitions.Count > 0)
                {
                    list.Append("<dl>" + Environment.NewLine);
                    while (Def_Title.Count > 0 || Definitions.Count > 0)
                    {
                        list.Append("\t<dt>" + Def_Title[0] + "</dt>" + Environment.NewLine);
                        list.Append("\t<dd>" + Definitions[0] + "</dd>" + Environment.NewLine);
                        Def_Title.RemoveAt(0);
                        Definitions.RemoveAt(0);
                    }
                    list.Append("</dl>" + Environment.NewLine);
                    HTML = list.ToString();
                }
                else
                {
                    return HTML;
                }
            }
            return list.ToString();
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnGeneratePage_Click(object sender, EventArgs e)
        {
            try
            {
                if (lvElementsToAdd.Items.Count == 0)
                    throw new Exception("List must have at least one element.");

                if (txtFilePath.Text == "")
                    throw new Exception("Please select a file path");

                if (txtPageName.Text == "")
                    throw new Exception("Please enter page name");
                if (txtTitle.Text == "")
                    throw new Exception("Please enter a title");

                StreamWriter stream = new StreamWriter(txtFilePath.Text + "\\" + txtPageName.Text + ".html", false);
                stream.WriteLine(create_HTML());
                stream.Close();

                MessageBox.Show("HTML File Created!!!");

                if (checkBoxOptionCSS.Checked)
                {
                    stream = new StreamWriter(txtFilePath.Text + "\\" + "style.css", false);
                    stream.WriteLine(create_CSS());
                    stream.Close();

                    MessageBox.Show("CSS File Created!!!");
                }

                clear_fields();
                txtFilePath.Text = "";
                txtPageName.Text = "";
                txtTitle.Text = "";

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        /// <summary>
        /// Create HTML file
        /// </summary>
        private String create_HTML()
        {
            string temp1, temp2 = "";
            StringBuilder HTML = new StringBuilder();
            try
            {
                HTML.Append("<!DOCTYPE html>" + Environment.NewLine);
                HTML.Append("<html>" + Environment.NewLine);
                HTML.Append("<head>" + Environment.NewLine);
                HTML.Append("\t<title>" +txtTitle.Text + "</title>" + Environment.NewLine);
                temp1 = @"""utf-8""";
                HTML.Append("\t<meta charset = " + temp1 + " />" + Environment.NewLine);
                if(checkBoxOptionCSS.Checked)
                {
                    temp1 = @"""stylesheet""";
                    temp2 = @"""style.css""";
                    HTML.Append("\t<link rel =" + temp1 + " href =" + temp2 + "/>" + Environment.NewLine);
                }
                    
                HTML.Append("</head>" + Environment.NewLine);
                
                //Add new Body Element
                HTML.Append("<body>" + Environment.NewLine);

                foreach (ListViewItem item in lvElementsToAdd.Items)
                {
                    switch (item.Text)
                    {
                        case "Heading1":
                            HTML.Append("\t<h1>" + item.SubItems[1].Text + "<h1>" + Environment.NewLine);
                            break;
                        case "Heading2":
                            HTML.Append("\t<h2>" + item.SubItems[1].Text + "<h2>" + Environment.NewLine);
                            break;
                        case "Heading3":
                            HTML.Append("\t<h3>" + item.SubItems[1].Text + "<h3>" + Environment.NewLine);
                            break;
                        case "Paragraph":
                            HTML.Append("\t<p>" + item.SubItems[1].Text + "<p>" + Environment.NewLine);
                            break;
                        case "Image":
                            HTML.Append("\t<img src = '" + item.SubItems[1].Text + "'>" + Environment.NewLine);
                            break;
                        case "Menu Bar":
                            HTML.Append(create_list(item));
                            break;
                        case "Ordered List":
                            HTML.Append(create_list(item));
                            break;
                        case "Unordered List":
                            HTML.Append(create_list(item));
                            break;
                        case "Definition List":
                            HTML.Append(create_list(item));
                            break;
                        default:
                            break;
                    }
                }

                //Close body element
                HTML.Append("</body>" + Environment.NewLine);
                HTML.Append("</html>" + Environment.NewLine);

                return HTML.ToString();
            }
            catch
            {
                return "";
            }
        }
        /// <summary>
        /// Create CSS file
        /// </summary>
        private String create_CSS()
        {
            StringBuilder CSS = new StringBuilder();
            try
            {
                //Set font for body element
                CSS.Append("body{" + Environment.NewLine);
                CSS.Append("\tfont-family: sans-serif;" + Environment.NewLine);
                CSS.Append("}" + Environment.NewLine);
                //Set style for list items
                CSS.Append("#menu li{" + Environment.NewLine);
                CSS.Append("\tdisplay: inline;" + Environment.NewLine);
                CSS.Append("\tpadding-right: 10px;" + Environment.NewLine);
                CSS.Append("}" + Environment.NewLine);
                //
                CSS.Append("ul a{" + Environment.NewLine);
                CSS.Append("\ttext-decoration: none;" + Environment.NewLine);
                CSS.Append("\tcolor: #666;" + Environment.NewLine);
                CSS.Append("}" + Environment.NewLine);
                //
                CSS.Append("ul a:hover{" + Environment.NewLine);
                CSS.Append("\ttext-decoration: underline;" + Environment.NewLine);
                CSS.Append("\tcolor: black;" + Environment.NewLine);
                CSS.Append("}" + Environment.NewLine);

                return CSS.ToString();
            }
            catch
            {
                return "";
            }
        }

        private void btnPreview_Click(object sender, EventArgs e)
        {
            frmBrowser browser = new frmBrowser(create_HTML());
            if (checkBoxOptionCSS.Checked)
            {
                StreamWriter stream = new StreamWriter(txtFilePath.Text + "\\" + "style.css", false);
                stream.WriteLine(create_CSS());
                stream.Close();
            }
            browser.Show();
        }

        private void txtFilePath_Click(object sender, EventArgs e)
        {
            FolderDialog.ShowDialog();
            txtFilePath.Text = FolderDialog.SelectedPath;
        }

        private void cboxElementType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboxElementType.Text == "Image")
            {
                OpenFileDialog SelectedImage = new OpenFileDialog();
                // Set validate names and check file exists to false otherwise windows will
                // not let you select "Folder Selection."
                SelectedImage.ValidateNames = false;
                SelectedImage.CheckFileExists = false;
                SelectedImage.CheckPathExists = true;
                // Always default to Folder Selection.
                SelectedImage.FileName = "Documents.";
                if (SelectedImage.ShowDialog() == DialogResult.OK)
                {
                    txtContent.Text = Path.GetFullPath(SelectedImage.FileName);
                }
            }

            if (cboxElementType.Text == "List")
            {
                lblListInstruction.Visible = true;
                lblListType.Visible = true;
                cbListType.Visible = true;
            }
            else
            {
                lblListInstruction.Visible = false;
                lblListType.Visible = false;
                cbListType.Visible = false;
            }

            lblDefinitionTitle.Visible = false;
            lblDefinition.Visible = false;
            txtDefinitionTitle.Enabled = false;
            txtDefinition.Enabled = false;
            txtContent.Enabled = true;
        }

        private void cbListType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbListType.Text == "Definition List")
            {
                lblDefinitionTitle.Visible = true;
                lblDefinition.Visible = true;
                txtDefinitionTitle.Enabled = true;
                txtDefinition.Enabled = true;
                txtContent.Enabled = false;
            }
            else
            {
                lblDefinitionTitle.Visible = false;
                lblDefinition.Visible = false;
                txtDefinitionTitle.Enabled = false;
                txtDefinition.Enabled = false;
                txtContent.Enabled = true;
            }

            if (cbListType.Text == "Menu Bar")
            {
                checkBoxOptionCSS.Checked = true;
            }
        }

        private void txtDefinition_EnterKey_Pressed(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)Keys.Enter)
            {
                Def_Title.Add(txtDefinitionTitle.Text);
                Definitions.Add(txtDefinition.Text);

                txtContent.Text += txtDefinitionTitle.Text + " - ";
                txtContent.Text += txtDefinition.Text + Environment.NewLine;
                txtDefinitionTitle.Text = "";
                txtDefinition.Text = "";
                txtDefinitionTitle.Focus();
            }
        }
    }
}
